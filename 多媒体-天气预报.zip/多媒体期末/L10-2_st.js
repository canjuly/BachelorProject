
// ..................变量声明...................
var canvas = document.getElementById('canvas'),
    context = canvas.getContext('2d'),
    citytext=document.getElementById('citytext'),
    weather='',
    citys='',
    lowtemperature,
    hightemperature,
    scale=0,
    step=0.01,
    flag=1,
    MAXIMUM_SCALE=4.0,

    image = new Image(),
    huzhou = new Image(),
    jiaxing = new Image(),
    shaoxing = new Image(),
    ningbo = new Image(),
    zhoushan = new Image(),
    jinhua = new Image(),
    quzhou = new Image(),
    lishui = new Image(),
    wenzhou = new Image(),
    taizhou = new Image(),
    sunnyimage = new Image(),
    cloudyimage = new Image(),
    overcastimage = new Image(),
    backgroundimage=new Image();

// 变量：动画帧
var animateFrame;
var interval;
    
// 定义雨的相关变量
var rainW = 1000, rainH = 500, rainangle = -10, rainlen = 30, raincount = 850;
// 定义雪的相关变量
var snowW = canvas.width, snowH = canvas.height, mp = 30/*max particles*/, particles = [], snowangle = 0;
    
// ..................函数定义...................

// .....借用已有函数.....


// .....自定义函数.....

// ----- 添加代码：绘制背景
function drawBackground() {
    if(citys=='杭州')
        context.drawImage(backgroundimage,0,0,canvas.width,canvas.height);
    else if(citys=='湖州')
        context.drawImage(huzhou,0,0,canvas.width,canvas.height);
    else if(citys=='嘉兴')
        context.drawImage(jiaxing,0,0,canvas.width,canvas.height);
    else if(citys=='绍兴')
        context.drawImage(shaoxing,0,0,canvas.width,canvas.height);
    else if(citys=='宁波')
        context.drawImage(ningbo,0,0,canvas.width,canvas.height);
    else if(citys=='舟山')
        context.drawImage(zhoushan,0,0,canvas.width,canvas.height);
    else if(citys=='金华')
        context.drawImage(jinhua,0,0,canvas.width,canvas.height);
    else if(citys=='丽水')
        context.drawImage(lishui,0,0,canvas.width,canvas.height);
    else if(citys=='衢州')
        context.drawImage(quzhou,0,0,canvas.width,canvas.height);
    else if(citys=='温州')
        context.drawImage(wenzhou,0,0,canvas.width,canvas.height);
    else if(citys=='台州')
        context.drawImage(taizhou,0,0,canvas.width,canvas.height);
    else
        context.drawImage(backgroundimage,0,0,canvas.width,canvas.height);
}

// ----- 添加代码：绘制天气

//画线
function xiayu(x, y) {
    
    context.beginPath();
    context.moveTo(x, y);
    context.lineTo(x + rainangle, y + rainlen);
    context.lineWidth = .5;
    context.stroke();
}
function update()
{
    snowangle += 0.01;
    for(var i = 0; i < mp; i++)
    {
        var p = particles[i];
        //Updating X and Y coordinates
        //We will add 1 to the cos function to prevent negative values which will lead flakes to move upwards
        //Every particle has its own density which can be used to make the downward movement different for each flake
        //Lets make it more random by adding in the radius
        p.y += Math.cos(snowangle+p.d) + 1 + p.r/2;
        p.x += Math.sin(snowangle) * 2;
        
        //Sending flakes back from the top when it exits
        //Lets make it a bit more organic and let flakes enter from the left and right also.
        if(p.x > snowW || p.x < 0 || p.y > snowH)
        {
            if(i%3 > 0) //66.67% of the flakes
            {
                particles[i] = {x: Math.random()*snowW, y: -10, r: p.r, d: p.d};
            }
            else
            {
                //If the flake is exitting from the right
                if(Math.sin(snowangle) > 0)
                {
                    //Enter fromth
                    particles[i] = {x: -5, y: Math.random()*snowH, r: p.r, d: p.d};
                }
                else
                {
                    //Enter from the right
                    particles[i] = {x: snowW+5, y: Math.random()*snowH, r: p.r, d: p.d};
                }
            }
        }
    }
}
function drawsnow(){
    
    context.fillStyle = "rgba(255, 255, 255, 0.8)";
    context.clearRect(0, 0, snowW, snowH);
    drawBackground();
    context.beginPath();
    for(var i = 0; i < mp; i++)
    {
        var p = particles[i];
        context.moveTo(p.x, p.y);
        context.arc(p.x, p.y, p.r, 0, Math.PI*2, true);
    }
    context.fill();
    update();
    context.fillStyle='aqua';
    context.fillText('地址：' + citys ,50,50);
    context.fillText('天气：' + weather ,50,100);
    context.fillText('温度:' + lowtemperature + '°' + '~' +hightemperature + '°' ,50,150);
}
function drawrain(){
    
    context.strokeStyle = 'rgba(255, 255, 250, 0.5)';//线条的样式
    context.clearRect(0, 0, canvas.width, canvas.height); //起始坐标/w线条宽度 h线条高度
    drawBackground();
    for (var i = 1; i <= raincount; i++) {
        xiayu(Math.random() * rainW, Math.random() * rainH);
    }
    context.fillText('地址：' + citys ,50,50);
    context.fillText('天气：' + weather ,50,100);
    context.fillText('温度:' + lowtemperature + '°' + '~' +hightemperature + '°' ,50,150);
}
function draw() {
    context.clearRect(0,0,canvas.width,canvas.height);
    drawBackground();
    context.fillText('地址：' + citys ,50,50);
    context.fillText('天气：' + weather ,50,100);
    context.fillText('温度:' + lowtemperature + '°' + '~' +hightemperature + '°' ,50,150);
     
    if(weather=='小雪'||weather=='中雪'||weather=='大雪'||weather=='阵雪'){
        interval= setInterval(drawsnow, 15);
    }
    else if(weather=='小雨'||weather=='中雨'||weather=='大雨'||weather=='阵雨'){
        interval= setInterval(drawrain, 100);
    }
    else{//可加入其他特效
        
    }
        
        
};
// ----- 添加代码：绘制当前帧
/*function drawFrame() {
    
}

// ------ 添加代码：动画循环调用的function
function animate() {
    //drawFrame();
    animateFrame=requestAnimationFrame(animate);
    if(weather=='小雪'||weather=='中雪'||weather=='大雪')
        drawsnow();
    else if(weather=='小雨'||weather=='中雨'||weather=='大雨'||weather=='阵雨'){
        drawrain();
    }
    else{
        cancelAnimationFrame(animateFrame);
        console.log(1);
    }
}*/


// .....事件响应.....
citytext.onchange=function(e){
    clearInterval(interval);
    citys=e.target.value;
    $.getScript("http://php.weather.sina.com.cn/js.php?" + 
                $.param({
                    city :  citys, //城市
                    day : 0,
                    password : "DJOYnieT8234jlsK"
                }) , function(json){
                        weather=status1;
                        lowtemperature=temperature2;
                        hightemperature=temperature1;
                        draw();
                    }
               );
    
    /*
        返回的数据
        city='北京';
        year1='14';//
        month1='02';
        day1='21';
        year2='14';
        month2='02';
        day2='22';
        city='北京';
        savedate_weather='2014-02-21';
        savedate_life='2014-02-21';
        savedate_zhishu='2014-02-21';
        status1='霾';
        status2='雾';
        figure1='mai';
        figure2='wu';
        direction1='无持续风向';
        direction2='无持续风向';
        power1='≤3';
        power2='≤3';
        temperature1='3';//白天温度
        temperature2='-2';//晚上温度
        */
}
// ..................初始化...................

context.font = "25px MS UI Gothic";
context.fillStyle='aqua';
//初始化雪花
for(var i = 0; i < mp; i++)
{
    particles.push({
        x: Math.random()*snowW, //x-coordinate
        y: Math.random()*snowH, //y-coordinate
        r: Math.random()*3+1, //radius
        d: Math.random()*mp //density
    })
}
// ----- 添加代码：加载图片

image.src='sun2.png';
huzhou.src='huzhou.jpg',
jiaxing.src='jiaxing.jpg',
shaoxing.src='shaoxing.jpg',
ningbo.src='ningbo.jpg',
zhoushan.src='zhoushan.jpg',
jinhua.src='jinhua.jpg',
quzhou.src='quzhou.jpg',
lishui.src='lishui.jpg',
wenzhou.src='wenzhou.jpg',
taizhou.src='taizhou.jpg',
backgroundimage.src='background.jpg';
backgroundimage.onload=function(e){
    context.drawImage(backgroundimage,0,0,canvas.width,canvas.height)
};
