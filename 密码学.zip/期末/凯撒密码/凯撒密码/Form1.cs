﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 凯撒密码
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            string key = textBox3.Text;
            string temp;
            if (textBox2.Text != "")
                temp = textBox2.Text;
            else
            {
                temp = System.IO.File.ReadAllText(textBox4.Text);
            }
            string output = "";
            int k = int.Parse(key);
            if (radioButton1.Checked)
            {
                for (int i = 0; i < temp.Length; i++)
                {
                    if ('a' <= temp[i] && temp[i] <= 'z')
                        output += (char)((temp[i] - 'a' + k) % 26 + 'a');
                    else if ('A' <= temp[i] && temp[i] <= 'Z')
                        output += (char)((temp[i] - 'A' + k) % 26 + 'A');
                    else if (temp[i] == ' ')
                        output += ' ';
                }
            }
            else
            {
                for (int i = 0; i < temp.Length; i++)
                {
                    if ('a' <= temp[i] && temp[i] <= 'z')
                    {
                        if ((temp[i] - 'a' - k) % 26 < 0)
                            output += (char)((temp[i] - 'a' - k) % 26 + 'a' + 26);
                        else
                            output += (char)((temp[i] - 'a' - k) % 26 + 'a');
                    }
                    else if ('A' <= temp[i] && temp[i] <= 'Z')
                    {
                        if ((temp[i] - 'A' - k) % 26 < 0)
                            output += (char)((temp[i] - 'A' - k) % 26 + 'A' + 26);
                        else
                            output += (char)((temp[i] - 'A' - k) % 26 + 'A');
                    }
                        
                    else if (temp[i] == ' ')
                        output += ' ';
                }
            }
            if(textBox2.Text!="")
                textBox1.Text = output;
            else
            {
                System.IO.File.WriteAllText(textBox4.Text, output, Encoding.UTF8);
                textBox1.Text = "原始文件已操作，请前去查看";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();

            fileDialog.InitialDirectory = "C://";

            fileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";

            fileDialog.FilterIndex = 1;

            fileDialog.RestoreDirectory = true;

            if (fileDialog.ShowDialog() == DialogResult.OK)

            {

                this.textBox4.Text = fileDialog.FileName;

            }
        }
    }
}
