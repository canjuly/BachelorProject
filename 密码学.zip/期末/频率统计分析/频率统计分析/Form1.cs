﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 频率统计分析
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string temp = textBox1.Text;
            string output = "";
            string outstring = "";
            int[] s = new int[300];
            string input = "";
            string[] now = new string[3000];
            int n = 0;
            for(int i=0;i<temp.Length;i++)
            {
                s[(int)temp[i]]++;
                if(temp[i]!=' '&&temp[i]!='\n')
                {
                    input += temp[i];
                }
                else
                {
                    now[n] = input;
                    n++;
                    input = "";
                }
            }
            now[n] = input;
            n++;
            for (int i=0;i<140;i++)
            {
                if (s[i] == 0)
                    continue;
                output += (char)(i);
                output += ": ";
                output += (s[i]*1.0*100/temp.Length).ToString("0.0");
                output += " %\r\n";
            }
            textBox2.Text = output;

            int maxn = 0, mark=0;
            for (int k = 0; k < 26; k++)
            {
                int ans = 0;
                for (int i = 0; i < n; i++)
                {
                    string tte = "";
                    for (int j = 0; j < now[i].Length; j++)
                    {
                        if ('a' <= now[i][j] && now[i][j] <= 'z')
                            tte += (char)((now[i][j] - 'a' + k) % 26 + 'a');
                    }
                    if (Array.IndexOf(ls, tte + '\r') != -1)
                    {
                        ans++;
                    }
                }
                if(ans>maxn)
                {
                    maxn = ans;
                    mark = k;
                }
            }
            for (int i = 0; i < n; i++)
            {
                //outstring += now[i];
                for (int j = 0; j < now[i].Length; j++)
                {
                    if ('a' <= now[i][j] && now[i][j] <= 'z')
                        outstring += (char)((now[i][j] - 'a' + mark) % 26 + 'a');
                }
                outstring += " ";
            }
            outstring += "\r\n";
            textBox4.Text = outstring;
        }

        string[] ls = new string[30000];
        private void Form1_Load(object sender, EventArgs e)
        {
            string temp = System.IO.File.ReadAllText("dictionary.txt");
            string input = "";
            int n = 0;
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] != '\n')
                    input += temp[i];
                else
                {
                    ls[n] = input;
                    input = "";
                    n++;
                }
            }
            //textBox4.Text = ls[12];
        }
    }
}
