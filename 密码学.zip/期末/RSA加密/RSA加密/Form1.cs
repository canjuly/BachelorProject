﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSA加密
{
    public partial class Form1 : Form
    {
        const int MAXSIZE = 100002;
        int[] Mark = new int[MAXSIZE];
        int[] prime = new int[MAXSIZE];
        int l, n, E;
        
        public Form1()
        {
            InitializeComponent();
        }

        int x, y;

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();

            fileDialog.InitialDirectory = "C://";

            fileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";

            fileDialog.FilterIndex = 1;

            fileDialog.RestoreDirectory = true;

            if (fileDialog.ShowDialog() == DialogResult.OK)

            {

                this.textBox3.Text = fileDialog.FileName;

            }
        }

        void extend_Euclid(int a, int b)
        {
            if (b == 0)
            {
                x = 1;
                y = 0;
                return;
            }
            extend_Euclid(b, a % b);
            int t = x;
            x = y;
            y = t - a / b * y;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random ra = new Random();
            int key = ra.Next() % 1000;
            int fake = ra.Next() % 10000;
            int p = prime[key];
            label2.Text = prime[key].ToString() + prime[fake].ToString();
            key = ra.Next(1000) % 1000;
            fake = ra.Next(10000) % 10000;
            int q= prime[key];
            label4.Text = prime[key].ToString() + prime[fake].ToString();
            l = (p - 1) * (q - 1);
            n = p * q;
            key = ra.Next(1000) % 100;
            E = prime[key];
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int index = 0;

            for (int i = 2; i < MAXSIZE; i++)
            {
                //如果未标记则得到一个素数  
                if (Mark[i] == 0)
                {
                    prime[index++] = i;
                }
                //标记目前得到的素数的i倍为非素数  
                for (int j = 0; j < index && prime[j] * i < MAXSIZE; j++)
                {
                    Mark[i * prime[j]] = 1;
                    if (i % prime[j] == 0)
                    {
                        break;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string temp;
            string output="";
            if (textBox1.Text != "")
                temp = textBox1.Text;
            else
            {
                temp = System.IO.File.ReadAllText(textBox3.Text);
            }
            /*output += l.ToString() + "\r\n";
            output += n.ToString() + "\r\n";
            output += E.ToString() + "\r\n";*/
            if (radioButton1.Checked)
            {
                for (int i=0;i<temp.Length;i++)
                {
                    long now = (int)temp[i];
                    long res = 1;
                    for(int j=0;j<E;j++)
                    {
                        res = res * now % n;
                    }
                    output += res.ToString() + " ";
                }
            }
            else
            {
                long d;
                extend_Euclid(E, l);
                d = (x % l + l) % l;
                //output += d.ToString();
                string input="";
                for(int i=0;i<temp.Length;i++)
                {
                    if(temp[i]!=' '&&temp[i]!='\n')
                    {
                        input += temp[i];
                    }
                    else
                    {
                        long now = long.Parse(input);
                        long res = 1;
                        for (int j = 0; j < d; j++)
                        {
                            res = res * now % n;
                        }
                        output += (char)res;
                        input = "";
                    }
                }
                if(input!="")
                {
                    long now = long.Parse(input);
                    long res = 1;
                    for (int j = 0; j < d; j++)
                    {
                        res = res * now % n;
                    }
                    output += (char)res + " ";
                }
            }
            if (textBox1.Text != "")
                textBox2.Text = output;
            else
            {
                System.IO.File.WriteAllText(textBox3.Text, output, Encoding.UTF8);
                textBox2.Text = "原始文件已操作，请前去查看";
            }
        }
    }
}
