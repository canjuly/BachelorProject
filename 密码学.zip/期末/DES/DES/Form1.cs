﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DES
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static byte[] Keys = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

        public static string EncryptDES(string encryptString, string encryptKey)//加密
        {
            try
            {           
                byte[] rgbKey = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 8));
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
                 DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
                 MemoryStream mStream = new MemoryStream();
                 CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                 cStream.Write(inputByteArray, 0, inputByteArray.Length);
                 cStream.FlushFinalBlock();
                return Convert.ToBase64String(mStream.ToArray());
             }
            catch
            {
                return encryptString;
            }
        }

        public static string DecryptDES(string decryptString, string decryptKey)//解密
        {
            try
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(decryptKey);
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Convert.FromBase64String(decryptString);
                 DESCryptoServiceProvider DCSP = new DESCryptoServiceProvider();
                 MemoryStream mStream = new MemoryStream();
                 CryptoStream cStream = new CryptoStream(mStream, DCSP.CreateDecryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                 cStream.Write(inputByteArray, 0, inputByteArray.Length);
                 cStream.FlushFinalBlock();
                return Encoding.UTF8.GetString(mStream.ToArray());
             }
            catch
             {
                return decryptString;
             }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string temp,output;

            if(textBox1.Text!="")
                temp= textBox1.Text;
            else
                temp = System.IO.File.ReadAllText(textBox4.Text);

            //textBox2.Text =temp;
            string sKey = textBox3.Text;
            if (radioButton1.Checked)
                output = EncryptDES(temp, sKey);
            else
                output = DecryptDES(temp, sKey);

            if (textBox1.Text != "")
                textBox2.Text = output;
            else
            {
                System.IO.File.WriteAllText(textBox4.Text, output, Encoding.UTF8);
                textBox2.Text = "原始文件已操作，请前去查看";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();

            fileDialog.InitialDirectory = "C://";

            fileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";

            fileDialog.FilterIndex = 1;

            fileDialog.RestoreDirectory = true;

            if (fileDialog.ShowDialog() == DialogResult.OK)

            {

                this.textBox4.Text = fileDialog.FileName;

            }
        }
    }
}
